<?php
	session_start();
	?>

	<?php require_once("includes/connection.php"); ?> 
	<?php
	
	


	if(!empty($_POST['name']) && !empty($_POST['password'])) {
	$name=htmlspecialchars($_POST['name']);
	$password=htmlspecialchars($_POST['password']);
	$query = mysqli_query($link, "SELECT * FROM users WHERE name='$name' AND password='$password'");
	$user = $query->fetch_assoc();
if(count($user) == 0) {
	echo "Неверное имя пользователя";
	exit();
}
	}
	
	setcookie('user', $user['name'], time() + 3600, "/");
	 
   header("Location: intropage.php");
	?>