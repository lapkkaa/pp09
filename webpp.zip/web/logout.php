<?php
	setcookie('user', $user['email'], time() - 3600, "/");
	if(isset($_SESSION['user'])) unset($_SESSION['user']);
	Header("Location: main.php");
?>