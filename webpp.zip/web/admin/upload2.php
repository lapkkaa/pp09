

<?php



	
	if(isset($_POST["upload"])){
	
	if(!empty($_POST['mark']) && !empty($_POST['model']) && !empty($_POST['img']) && !empty($_POST['price'])) {
 $type=htmlspecialchars($_POST['type']);
        $model=htmlspecialchars($_POST['model']);
 $mark=htmlspecialchars($_POST['mark']);
 $img=htmlspecialchars($_POST['img']);
 $price=htmlspecialchars($_POST['price']);
 $n1=mysqli_connect("localhost","root","","nds2");
 $query =mysqli_query($n1, "SELECT * FROM catalog WHERE mark='".$mark."' AND model='".$model."'");
 $numrows=mysqli_num_rows($query);
if($numrows==0)
   {
	$sql="INSERT INTO catalog (type, mark, model, img, price) VALUES('$type', '$mark', '$model', '$img', '$price')";
  $result=mysqli_query($n1, $sql);
 if($result){
	$message = "Товар успешно добавлен!";
} else {
 $message = "Ошибка загрузки товара!";
  }
	} else {
	$message = "Такой товар уже есть!";
   }
	} else {
	$message = "Требуется заполнить все поля!";
	}
	}
	?>
