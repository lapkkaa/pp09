<?php
require("admin_cons.php");
$link = mysqli_connect("$host", "$user", "$password")or die("cannot connect server ");
mysqli_select_db($link,"$database")or die("cannot select DB");
