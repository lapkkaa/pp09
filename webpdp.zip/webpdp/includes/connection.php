<?php
require("constants.php");
$link = mysqli_connect("$host", "$user", "$password")or die("cannot connect server ");
mysqli_select_db($link,"$database")or die("cannot select DB");
mysqli_query($link, "SET NAMES 'utf8'");
ini_set('display_errors', 0);
