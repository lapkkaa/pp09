<?php
$logs = true;
$len = count($_FILES['files']['name']);
for($i = 0; $i < $len; $i++) {
    switch ($_FILES['files']['type'][$i]) {
        case 'image/png' : $catalog = '../view';
        $logs = false;
        break;
        case 'text/xml' : $catalog = '../view';
        $logs = true;
        break;
    default:
    echo "Проблема - файл не является PNG";
    exit;
    }
$upfile = $catalog . $_FILES['files']['name'][$i];
if (is_uploaded_file($_FILES['files']['tmp_name'][$i])) {
    if (!move_uploaded_file($_FILES['files']['tmp_name'][$i], $upfile)) {
        echo 'Проблема невозможно переместить файл в каталог назначения';
        exit; }
    } else {
        echo 'Проблема возможна атака через загрузку файла. Файл: ';
        echo $_FILES['files']['name'][$i];
        exit;
    }
echo 'Файл' . $upfile . ' успешно загружен. <br /> <br />';
if ($logs) {
    $contents = file_get_contents($upfile);
    echo 'Предварительный просмотр содержимого загруженного файла:<br /> <hr />';
    echo nl2br($contents);
    echo '<br><hr>';
}
}
?>