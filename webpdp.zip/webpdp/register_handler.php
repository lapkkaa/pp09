<?php
	
	if(isset($_POST["register"])){
	
	if(!empty($_POST['email']) && !empty($_POST['name']) && !empty($_POST['password'])) {
 $email=htmlspecialchars($_POST['email']);
 $name=htmlspecialchars($_POST['name']);
 $password=htmlspecialchars($_POST['password']);
 $n1=mysqli_connect("localhost","root","","nds2");
 $query =mysqli_query($n1, "SET NAMES 'utf8'", "SELECT * FROM users WHERE name='".$name."' AND password='".$password."'");
 $numrows=mysqli_num_rows($query);
if($numrows==0)
   {
	$sql="INSERT INTO users (email, name, password) VALUES('$email', '$name', '$password')";
  $result=mysqli_query($n1, $sql);
 if($result){
	$message = "Account Successfully Created";
} else {
 $message = "Failed to insert data information!";
  }
	} else {
	$message = "That username already exists! Please try another one!";
   }
	} else {
	$message = "All fields are required!";
	}
	}
    header("Location: main.php");
	?>
